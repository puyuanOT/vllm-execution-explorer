#!/usr/bin/env python3
"""Evidence-only bounded API checks against the existing isolated GPU controller."""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import time

ROOT = Path('/home/ubuntu/vllm-execution-explorer-3d-learning-7da8f31')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--source-ref', required=True)
parser.add_argument('--source-sha256', required=True)
parser.add_argument('--controller-pid', type=int, required=True)
args = parser.parse_args()
OUTPUT = args.output.resolve()
if not OUTPUT.is_relative_to((ROOT / 'recordings').resolve()):
    raise ValueError('Evidence output must stay in the controller recording folder.')
BASE = 'http://127.0.0.1:8780'
EXPECTED_SOURCE = args.source_sha256
TIMEOUT = 240

spec = importlib.util.spec_from_file_location('qualification', ROOT / 'docs/qualification/3d-learning-gpu/qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)


def require_idle():
    state = q.api(BASE, '/api/runs/current')
    if state['active']:
        raise RuntimeError('Refusing to launch alongside another active capture.')
    return state


def copy_recording(run_id, destination):
    source = ROOT / 'recordings/runs' / run_id
    shutil.copytree(source, destination / 'recording')
    # Retain both the complete controller files and their final public response.
    q.save(destination / 'public-manifest.json', q.api(BASE, f'/api/recordings/{run_id}/manifest'))


def capture(name, payload, *, late=None):
    require_idle()
    destination = OUTPUT / name
    q.save(destination / 'request.json', payload)
    q.RunRequest(**payload)
    requests, plan = q.parse_run_workload(payload)
    q.parse_run_configuration(payload, requests, plan)
    q.save(destination / 'gpu-memory-before.json', q.gpu_memory_receipt())
    launch = q.api(BASE, '/api/runs', payload)
    q.save(destination / 'launch.json', launch)
    run_id = launch['run_id']
    if late is None:
        q.save(destination / 'close-intake.json', q.api(BASE, '/api/runs/current/close-intake', {}))
    sequence, last_phase, admitted_late, history = 0, None, False, []
    deadline = time.monotonic() + TIMEOUT
    while time.monotonic() < deadline:
        current = q.api(BASE, '/api/runs/current')
        if current['run_id'] != run_id:
            raise RuntimeError('Controller switched captures; refusing to change another run.')
        trace = q.api(BASE, f'/api/runs/{run_id}/trace?after_sequence={sequence}&limit=2000')
        sequence = trace['next_event_sequence']
        phase = (trace.get('capture') or {}).get('phase') or trace['status']
        if phase != last_phase:
            history.append({'observed_monotonic_ns': time.monotonic_ns(), 'phase': phase,
                            'status': trace['status'], 'after_sequence': sequence})
            print(f'{name}: {run_id}: {phase}', flush=True)
            last_phase = phase
        if late is not None and not admitted_late and phase == 'dispatching_workload':
            q.save(destination / 'added-request.json', late)
            response = q.api(BASE, '/api/runs/current/requests', late)
            q.save(destination / 'added-response.json', response)
            if response != {'accepted': True}:
                raise RuntimeError('Late request was not accepted.')
            q.save(destination / 'close-intake.json', q.api(BASE, '/api/runs/current/close-intake', {}))
            admitted_late = True
        if trace['finalized']:
            q.save(destination / 'phase-observations.json', history)
            q.save(destination / 'final-state.json', trace)
            q.save(destination / 'final-current.json', current)
            q.save(destination / 'gpu-memory-after.json', q.gpu_memory_receipt())
            copy_recording(run_id, destination)
            return destination, trace, admitted_late
        time.sleep(0.05)
    q.save(destination / 'timeout-cancel.json', q.api(BASE, '/api/runs/current/cancel', {}))
    raise TimeoutError(f'Owned capture {run_id} exceeded {TIMEOUT}s; cancellation requested, no later capture launched.')


def reviewed_output(data):
    texts = {}
    for row in data.content:
        if row.get('kind') == 'text':
            texts[row['request_id']] = texts.get(row['request_id'], '') + row.get('text_delta', '')
    return {'output_text': texts, 'actual_output_token_ids': data.manifest.get('engine_output_token_ids', {}),
            'canonical_run_configuration': data.manifest.get('run_configuration'),
            'returned_sampling': data.manifest.get('sampling'),
            'engine_settings': data.manifest.get('engine_settings'),
            'actual_execution_process': data.manifest.get('execution_process')}


def check(label, ok, detail):
    return {'check': label, 'ok': bool(ok), 'detail': detail}


def memory_idle(destination):
    receipt = json.loads((destination / 'gpu-memory-after.json').read_text())
    return receipt.get('status') == 'observed' and receipt.get('compute_apps', {}).get('rows') == []


def main():
    identity = q.source_identity(ROOT)
    if (OUTPUT / 'source-receipt.json').exists():
        raise RuntimeError('Refusing to overwrite an existing evidence execution.')
    if identity['source_sha256'] != EXPECTED_SOURCE:
        raise RuntimeError('Capture source does not match the specified committed fingerprint.')
    initial = require_idle()
    q.save(OUTPUT / 'source-receipt.json', {'source_revision': args.source_ref,
        'source_identity': identity, 'controller_pid': args.controller_pid, 'controller_base_url': BASE,
        'initial_state_summary': {'run_id': initial['run_id'], 'status': initial['status'], 'active': initial['active']},
        'timeout_seconds_per_case': TIMEOUT,
        'observability_requirement': 'LangSmith waived by user for this project.'})
    results = []

    from argparse import Namespace
    execution = Namespace(output=OUTPUT, base_url=BASE, timeout=TIMEOUT,
                          gpu_memory=True, recordings=ROOT / 'recordings/runs')
    for name in ('staggered', 'cancel-profile'):
        require_idle()
        payload = q.cases()[name]
        q.save(OUTPUT / name / 'request.json', payload)
        result = q.execute(name, payload, execution)
        data = q.load_recording(OUTPUT / name / 'recording')
        q.save(OUTPUT / name / 'reviewed-output-configuration.json', reviewed_output(data))
        results.append(result)

    failed = copy.deepcopy(q.cases()['staggered'])
    failed.update(max_model_len=256, kv_cache_memory_bytes=1, requests=[q.request('expected-preparation-failure', 'Reply with the word ready.', output=8)])
    destination, trace, _ = capture('preparation-failure', failed)
    data = q.load_recording(destination / 'recording')
    report = q.evaluate(data)
    (destination / 'recording/integrity-report.txt').write_text(report.text())
    message = trace.get('message', '')
    process = data.manifest.get('execution_process', {})
    failed_codes = [finding.code for finding in report.findings if not finding.ok]
    before_capture = not data.events and failed_codes == ['sequences'] and not any(phase['phase'] == 'capture_ready' for phase in data.manifest.get('capture', {}).get('phase_history', []))
    checks = [check('failed preparation reported and finalized', trace['status'] == 'failed' and trace['finalized'], message),
        check('capacity-related failure retained', 'cache' in message.lower() and any(word in message.lower() for word in ('memory', 'block', 'capacity')), message),
        check('no request admitted after preparation failure', not any(event['event_type'] == 'engine_admitted' for event in data.events), len(data.events)),
        check('retained failed-preparation evidence parses; ordinary empty-stream capture report is not applicable', before_capture, {'report_ok': report.ok, 'inapplicable_before_capture': before_capture, 'original_report': report.text()}),
        check('no observed GPU execution is claimed before preparation completes', data.manifest.get('provenance', {}).get('real_gpu') is False, data.manifest.get('provenance')),
        check('failed worker exited before readiness', process.get('status') == 'exited' and process.get('exit_code') == 0, process),
        check('failed engine leaves no GPU compute allocation', memory_idle(destination), json.loads((destination / 'gpu-memory-after.json').read_text()))]
    result = {'case': 'preparation-failure', 'run_id': data.manifest['run_id'], 'ok': all(item['ok'] for item in checks), 'checks': checks}
    q.save(destination / 'assessment.json', result)
    q.save(destination / 'reviewed-output-configuration.json', reviewed_output(data))
    results.append(result)
    print(f"preparation-failure: {'PASS' if result['ok'] else 'FAIL'}", flush=True)

    recovery = copy.deepcopy(q.cases()['staggered'])
    recovery['requests'] = [q.request('planned-after-10s', 'Reply with the word scheduled.', 10000, 8)]
    late = q.request('late-immediate', 'Reply with the word admitted.', output=8)
    destination, trace, admitted = capture('recovery-late-intake', recovery, late=late)
    data = q.load_recording(destination / 'recording')
    result = q.assess('recovery-late-intake', destination / 'recording', {**recovery, 'requests': [*recovery['requests'], late]})
    admissions = {event['request_id']: event['sequence'] for event in data.events if event['event_type'] == 'engine_admitted'}
    completions = {event['request_id']: event['sequence'] for event in data.events if event['event_type'] == 'completion'}
    stop_terminals = [event for event in data.events if event['event_type'] == 'completion' and event.get('reason') == 'stop']
    result['checks'].extend([
        check('both natural STOP results have explicit native completion terminals', {event['request_id'] for event in stop_terminals} == {'late-immediate', 'planned-after-10s'}, stop_terminals),
        check('late API request accepted before closing intake', admitted, json.loads((destination / 'added-response.json').read_text())),
        check('late immediate request completes before planned 10s admission', completions.get('late-immediate', 10**12) < admissions.get('planned-after-10s', -1), {'admissions': admissions, 'completions': completions}),
        check('owned recovery worker exited and GPU has no compute allocation', memory_idle(destination), data.manifest['execution_process'])])
    result['ok'] = all(item['ok'] for item in result['checks'])
    q.save(destination / 'assessment.json', result)
    q.save(destination / 'reviewed-output-configuration.json', reviewed_output(data))
    results.append(result)
    print(f"recovery-late-intake: {'PASS' if result['ok'] else 'FAIL'}", flush=True)
    final = require_idle()
    q.save(OUTPUT / 'final-idle.json', final)
    q.save(OUTPUT / 'gpu-memory-final.json', q.gpu_memory_receipt())
    q.save(OUTPUT / 'results.json', results)
    print('GPU_IDLE: all owned execution processes have exited.', flush=True)
    return 0 if all(result['ok'] for result in results) else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        q.save(OUTPUT / 'execution-error.json', {'error': str(error), 'type': type(error).__name__,
            'current_state': q.api(BASE, '/api/runs/current'), 'gpu_memory': q.gpu_memory_receipt()})
        raise
