import json,os,signal,subprocess,time,sys,urllib.request
from pathlib import Path
root=Path('/home/ubuntu/vllm-execution-explorer-3d-learning-7da8f31')
revision='dcab49f6ff0e194711c031f4d72399b93f300877'
expected='c48b0fd1c8eccdc0b0d1d1d37e08b02f854a6e8bfd13531f81bf116bc524704d'
current=json.load(urllib.request.urlopen('http://127.0.0.1:8780/api/runs/current',timeout=10))
assert current['active'] is False, 'Refusing to restart an active owned controller'
old_pid=int((root/'runner.pid').read_text())
assert os.readlink(f'/proc/{old_pid}/cwd')==str(root)
assert Path(f'/proc/{old_pid}/cmdline').read_text().split('\0')[1:5]==['-m','runner','--port','8780']
os.kill(old_pid,signal.SIGTERM)
deadline=time.monotonic()+15
while Path(f'/proc/{old_pid}').exists() and time.monotonic()<deadline:
    time.sleep(.1)
assert not Path(f'/proc/{old_pid}').exists(), 'Old owned controller did not exit; no replacement launched'
env=dict(os.environ)
env['PATH']=str(root/'.venv/bin')+':'+env.get('PATH','')
env['PYTHONPATH']=str(root)+':'+str(root/'instrumentation')
env['VLLM_EXPLORER_CODE_REVISION']=revision
env['PYTHONUNBUFFERED']='1'
with (root/'runner.log').open('ab') as log:
    process=subprocess.Popen([str(root/'.venv/bin/python'),'-m','runner','--port','8780'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'runner.pid').write_text(str(process.pid)+'\n')
deadline=time.monotonic()+30
while time.monotonic()<deadline:
    if process.poll() is not None: raise RuntimeError('Owned controller exited during startup')
    try:
        health=json.load(urllib.request.urlopen('http://127.0.0.1:8780/api/health',timeout=2))
        break
    except Exception: time.sleep(.1)
else: raise TimeoutError('Owned controller did not report health')
sys.path[:0]=[str(root),str(root/'instrumentation')]
from runner.observability import source_identity
identity=source_identity(root)
assert identity['source_sha256']==expected
print(json.dumps({'source_revision':revision,'source_identity':identity,'controller_pid':process.pid,'controller_cwd':os.readlink(f'/proc/{process.pid}/cwd'),'prior_owned_controller_pid':old_pid,'original_controller_pid':4007,'original_controller_alive':Path('/proc/4007').exists(),'health':health,'gpus':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,compute_cap,driver_version','--format=csv,noheader'],text=True).splitlines(),'gpu_memory_mib':subprocess.check_output(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True).strip(),'compute_apps':subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader'],text=True).splitlines()},indent=2))
