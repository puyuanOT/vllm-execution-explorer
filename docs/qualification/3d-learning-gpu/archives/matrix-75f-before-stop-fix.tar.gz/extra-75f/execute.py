#!/usr/bin/env python3
"""Evidence-only bounded API checks against the existing isolated GPU controller."""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import shutil
import time

ROOT = Path('/home/ubuntu/vllm-execution-explorer-3d-learning-7da8f31')
OUTPUT = ROOT / 'recordings/qualification-extra-75f'
BASE = 'http://127.0.0.1:8780'
EXPECTED_SOURCE = 'af7f86400baecd380b7ec08de10ac26f8bf320e22108fff5b7e20d4cbff5703c'
TIMEOUT = 240

spec = importlib.util.spec_from_file_location('qualification', ROOT / 'docs/qualification/3d-learning-gpu/qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)


def require_idle():
    state = q.api(BASE, '/api/runs/current')
    if state['active']:
        raise RuntimeError('Refusing to launch alongside another active capture.')
    return state


def copy_recording(run_id, destination):
    source = ROOT / 'recordings/runs' / run_id
    shutil.copytree(source, destination / 'recording')
    # Retain both the complete controller files and their final public response.
    q.save(destination / 'public-manifest.json', q.api(BASE, f'/api/recordings/{run_id}/manifest'))


def capture(name, payload, *, late=None):
    require_idle()
    destination = OUTPUT / name
    q.save(destination / 'request.json', payload)
    q.RunRequest(**payload)
    requests, plan = q.parse_run_workload(payload)
    q.parse_run_configuration(payload, requests, plan)
    q.save(destination / 'gpu-memory-before.json', q.gpu_memory_receipt())
    launch = q.api(BASE, '/api/runs', payload)
    q.save(destination / 'launch.json', launch)
    run_id = launch['run_id']
    if late is None:
        q.save(destination / 'close-intake.json', q.api(BASE, '/api/runs/current/close-intake', {}))
    sequence, last_phase, admitted_late, history = 0, None, False, []
    deadline = time.monotonic() + TIMEOUT
    while time.monotonic() < deadline:
        current = q.api(BASE, '/api/runs/current')
        if current['run_id'] != run_id:
            raise RuntimeError('Controller switched captures; refusing to change another run.')
        trace = q.api(BASE, f'/api/runs/{run_id}/trace?after_sequence={sequence}&limit=2000')
        sequence = trace['next_event_sequence']
        phase = (trace.get('capture') or {}).get('phase')
        if phase != last_phase:
            history.append({'observed_monotonic_ns': time.monotonic_ns(), 'phase': phase,
                            'status': trace['status'], 'after_sequence': sequence})
            print(f'{name}: {run_id}: {phase}', flush=True)
            last_phase = phase
        if late is not None and not admitted_late and phase == 'dispatching_workload':
            q.save(destination / 'added-request.json', late)
            response = q.api(BASE, '/api/runs/current/requests', late)
            q.save(destination / 'added-response.json', response)
            if response != {'accepted': True}:
                raise RuntimeError('Late request was not accepted.')
            q.save(destination / 'close-intake.json', q.api(BASE, '/api/runs/current/close-intake', {}))
            admitted_late = True
        if trace['finalized']:
            q.save(destination / 'phase-observations.json', history)
            q.save(destination / 'final-state.json', trace)
            q.save(destination / 'final-current.json', current)
            q.save(destination / 'gpu-memory-after.json', q.gpu_memory_receipt())
            copy_recording(run_id, destination)
            return destination, trace, admitted_late
        time.sleep(0.05)
    q.save(destination / 'timeout-cancel.json', q.api(BASE, '/api/runs/current/cancel', {}))
    raise TimeoutError(f'Owned capture {run_id} exceeded {TIMEOUT}s; cancellation requested, no later capture launched.')


def reviewed_output(data):
    texts = {}
    for row in data.content:
        if row.get('kind') == 'response_text_delta':
            texts[row['request_id']] = texts.get(row['request_id'], '') + row.get('text_delta', '')
    return {'output_text': texts, 'actual_output_token_ids': data.manifest.get('engine_output_token_ids', {}),
            'effective_configuration': data.manifest.get('effective_configuration'),
            'engine_settings': data.manifest.get('engine_settings'),
            'actual_execution_process': data.manifest.get('execution_process')}


def check(label, ok, detail):
    return {'check': label, 'ok': bool(ok), 'detail': detail}


def memory_idle(destination):
    receipt = json.loads((destination / 'gpu-memory-after.json').read_text())
    return receipt.get('status') == 'observed' and receipt.get('compute_apps', {}).get('rows') == []


def main():
    identity = q.source_identity(ROOT)
    if identity['source_sha256'] != EXPECTED_SOURCE:
        raise RuntimeError('Capture source does not match the authorized 75f fingerprint.')
    initial = require_idle()
    q.save(OUTPUT / 'source-receipt.json', {'authorized_revision': '75f2ccd3a13b585c576f2597449a23dcad670921',
        'source_identity': identity, 'controller_pid': 9861, 'controller_base_url': BASE,
        'initial_state_summary': {'run_id': initial['run_id'], 'status': initial['status'], 'active': initial['active']},
        'timeout_seconds_per_case': TIMEOUT,
        'observability_requirement': 'LangSmith waived by user for this project.'})
    results = []

    pressure = copy.deepcopy(q.cases()['pressure'])
    pressure['max_model_len'] = 480
    for request in pressure['requests']:
        request['max_output_tokens'] = 256
    destination, trace, _ = capture('pressure-preemption', pressure)
    data = q.load_recording(destination / 'recording')
    result = q.assess('pressure', destination / 'recording', pressure)
    preemptions = [event for event in data.events if event['event_type'] == 'preemption']
    result['checks'].extend([
        check('actual preemption observed', bool(preemptions), {'count': len(preemptions), 'events': preemptions}),
        check('owned execution process exited and GPU has no compute allocation', memory_idle(destination), data.manifest['execution_process'])])
    result['ok'] = all(item['ok'] for item in result['checks'])
    result['case'] = 'pressure-preemption'
    q.save(destination / 'assessment.json', result)
    q.save(destination / 'reviewed-output-configuration.json', reviewed_output(data))
    results.append(result)
    print(f"pressure-preemption: {'PASS' if result['ok'] else 'OBSERVATION DID NOT QUALIFY'} ({len(preemptions)} preemptions)", flush=True)

    failed = copy.deepcopy(q.cases()['staggered'])
    failed.update(max_model_len=256, kv_cache_memory_bytes=1, requests=[q.request('expected-preparation-failure', 'Reply with the word ready.', output=8)])
    destination, trace, _ = capture('preparation-failure', failed)
    data = q.load_recording(destination / 'recording')
    report = q.evaluate(data)
    (destination / 'recording/integrity-report.txt').write_text(report.text())
    message = trace.get('message', '')
    process = data.manifest.get('execution_process', {})
    checks = [check('failed preparation reported and finalized', trace['status'] == 'failed' and trace['finalized'], message),
        check('capacity-related failure retained', 'cache' in message.lower() and any(word in message.lower() for word in ('memory', 'block', 'capacity')), message),
        check('no request admitted after preparation failure', not any(event['event_type'] == 'engine_admitted' for event in data.events), len(data.events)),
        check('failed capture integrity', report.ok, report.text()),
        check('failed worker exited before readiness', process.get('status') == 'exited' and process.get('exit_code') == 0, process),
        check('failed engine leaves no GPU compute allocation', memory_idle(destination), json.loads((destination / 'gpu-memory-after.json').read_text()))]
    result = {'case': 'preparation-failure', 'run_id': data.manifest['run_id'], 'ok': all(item['ok'] for item in checks), 'checks': checks}
    q.save(destination / 'assessment.json', result)
    q.save(destination / 'reviewed-output-configuration.json', reviewed_output(data))
    results.append(result)
    print(f"preparation-failure: {'PASS' if result['ok'] else 'FAIL'}", flush=True)

    recovery = copy.deepcopy(q.cases()['staggered'])
    recovery['requests'] = [q.request('planned-after-10s', 'Reply with the word scheduled.', 10000, 8)]
    late = q.request('late-immediate', 'Reply with the word admitted.', output=8)
    destination, trace, admitted = capture('recovery-late-intake', recovery, late=late)
    data = q.load_recording(destination / 'recording')
    result = q.assess('recovery-late-intake', destination / 'recording', {**recovery, 'requests': [*recovery['requests'], late]})
    admissions = {event['request_id']: event['sequence'] for event in data.events if event['event_type'] == 'engine_admitted'}
    completions = {event['request_id']: event['sequence'] for event in data.events if event['event_type'] == 'completion'}
    result['checks'].extend([
        check('late API request accepted before closing intake', admitted, json.loads((destination / 'added-response.json').read_text())),
        check('late immediate request completes before planned 10s admission', completions.get('late-immediate', 10**12) < admissions.get('planned-after-10s', -1), {'admissions': admissions, 'completions': completions}),
        check('owned recovery worker exited and GPU has no compute allocation', memory_idle(destination), data.manifest['execution_process'])])
    result['ok'] = all(item['ok'] for item in result['checks'])
    q.save(destination / 'assessment.json', result)
    q.save(destination / 'reviewed-output-configuration.json', reviewed_output(data))
    results.append(result)
    print(f"recovery-late-intake: {'PASS' if result['ok'] else 'FAIL'}", flush=True)
    final = require_idle()
    q.save(OUTPUT / 'final-idle.json', final)
    q.save(OUTPUT / 'gpu-memory-final.json', q.gpu_memory_receipt())
    q.save(OUTPUT / 'results.json', results)
    print('GPU_IDLE: all owned execution processes have exited.', flush=True)
    return 0 if all(result['ok'] for result in results) else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        q.save(OUTPUT / 'execution-error.json', {'error': str(error), 'type': type(error).__name__,
            'current_state': q.api(BASE, '/api/runs/current'), 'gpu_memory': q.gpu_memory_receipt()})
        raise
