# Extra 75f observed outcomes

The pressure case qualified with three native preemptions, four completed 256-output synthetic requests, a full 32-block physical pool, and an effective 72 MiB KV budget/context 480. The repeated-digit prose is expected for synthetic structural inputs. No scheduler decision cause is inferred.

The 1-byte KV case failed as intended before workload capture with the native cache-capacity error. No request was admitted. The ordinary recording report flags zero events; that check is inapplicable before capture, and its original failure is preserved. The worker exited, GPU memory returned to 3 MiB, and a following capture launched successfully.

Late intake accepted the immediate request and returned the correct words `admitted` and `scheduled` for both requests. Both HTTP responses have stop terminals. The adapter omitted native completion because the native zero-valued STOP enum was tested for truthiness. This defect was corrected in separate commit cee0b6a; the 75f evidence remains an unmodified failing iteration. The final 8f0 rerun qualifies its native completions and final-token boundaries.

All three worker processes exited. Post-close receipts show 3 MiB GPU memory and no compute applications. This is validation by the execution agent; independent final review is separate.

Full outputs, effective configuration, terminals, process identities and memory receipts are in each `actual-output-outcome-review.json`. The original script, raw recordings, initial assessments and integrity reports are preserved.
