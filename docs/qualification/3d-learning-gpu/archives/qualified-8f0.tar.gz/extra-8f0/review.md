# Extra 8f0 qualification

All three bounded cases passed on implementation 8f0 with capture source 83df. The execution script, log, requests, launches, full recordings, phase observations and memory receipts are retained. This is validation by the execution agent; independent final review is separate.

- Pressure run 9ff4ff7f29ba: 72 MiB KV budget, context 480, four 192-token synthetic prompts and 256-output limits. The full physical pool has 32 blocks, including null block 0, leaving 31 usable blocks of 16 tokens each. Three preemptions were observed; all four requests accepted 256 outputs and completed. Their repeated-digit text qualifies structural behavior. No scheduler decision cause is inferred.
- Expected preparation failure run 5cd47c5ab70a: a 1-byte KV budget produces the retained native cache-capacity error before any request admission. Its manifest correctly claims no observed GPU execution. The ordinary integrity report's zero-event finding is inapplicable before capture; the original report remains stored. The following capture recovered successfully.
- Late-intake recovery run 1cd5db48bd59: the immediate request was accepted through the API while the initial request remained planned for 10 seconds. Returned text is exactly `admitted` and `scheduled`, with 3 and 2 accepted token IDs including their stop tokens. Both native completion events have reason `stop`; late completion precedes planned admission. The ordinary assessment and actual frontend replay audit pass, including final sampled tokens remaining uncomputed.

Both the pressure and late-intake recordings pass the existing contract auditor against preserved Git ref 8f0, including actual frontend projections of the full pool and final tokens. Every owned worker exited. Each post-close memory receipt reports 3 MiB and no GPU compute application. No further GPU case was launched after these extras.

Full returned text and canonical/effective configuration are in each `reviewed-output-configuration.json`. The structured summary is in `outcome-review.json`; native preemption and completion observations remain in the recordings.
